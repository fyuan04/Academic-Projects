####analysis with association rules
library(arules)
library(arulesViz)
library(dplyr)
library(tidyverse)

#read the cleaned data
newdata <- read.csv(file = "revision.csv")
#customer oriented columns mentioned below refer to airline.status, class, and type.of.travel
#flights oriented columns mentioned below refer to origin.state, destination.state, departure.index,
#arrival&departure delays, flight.time.index, and distance.index

##############################For Cheapseats
cheapseats <- filter(newdata,newdata$Partner.Code=="WN")
#extract customer oriented columns
cheap <- cheapseats[,c(3,10,14,25)]
#make sure all the variables are factors
cheap <- cheap %>% mutate_all(as.factor)
#apply association rules to detractors
cheapX <- as(cheap,"transactions")
ruleset <- apriori(cheapX,
                   parameter = list(support=0.005,confidence=0.5),
                   appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset)

#promoter: no conclusion
#detractor: blue+personal travel     (low end sattus and class)

#flights oriented columns
cheap2 <- cheapseats[,c(17,18,19,20,21,23,24,25)]
#create a new column, if delayed, show 1, if no delay show 0
cheap2$Delay <- ifelse((cheap2$DDIM.Index<2)&(cheap2$ADIM.Index>0),0,1)
cheap2 <- cheap2[,c(1,2,3,6,9,8)]
cheap2 <- cheap2 %>% mutate_all(as.factor)
cheap2X <- as(cheap2,"transactions")
ruleset2 <- apriori(cheap2X,
                    parameter = list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset2)
#promoters:no conclusion
#detractors: TEXAS as origin state


###########################For Sigma Airlines
sigma <-filter(newdata,newdata$Partner.Code=="DL")
#customer oriented
sig1 <- sigma[,c(3,10,14,25)]
sig1 <- sig1 %>% mutate_all(as.factor)
sig1X <- as(sig1,"transactions")
ruleset3 <- apriori(sig1X,
                    parameter = list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset3)
#promoters:no conclusion
#detractors: [1] personal travel
#            [2] Blue + personal travel
#            [3] personal travel+ eco

#flights oriented
sig2 <- sigma[,c(17,18,19,20,21,23,24,25)]
sig2$Delay <- ifelse((sig2$DDIM.Index<2)&(sig2$ADIM.Index>0),0,1)
sig2 <- sig2[,c(1,2,3,6,9,8)]
sig2 <- sig2 %>% mutate_all(as.factor)
sig2X <- as(sig2,"transactions")
ruleset4 <- apriori(sig2X,
                    parameter = list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset4)
#promoters:no conclusion
#detractors: TEXAS


#########################For Flyfast
flyfast <- filter(newdata,newdata$Partner.Code=="EV")
#customer oriented
ffast <- flyfast[,c(3,10,14,25)]
#apply association rules to detractors
ffast <- ffast %>% mutate_all(as.factor)
str(ffast)
ffastX <- as(ffast,"transactions")
ruleset5 <- apriori(ffastX,
                   parameter = list(support=0.005,confidence=0.5),
                   appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset5)
#promoters: model does not work
#detractors: Blue+personal travel

#flights oriented columns
ffast2 <- flyfast[,c(17,18,19,20,21,23,24,25)]
#create a new column, if delayed, show 1, if no delay show 0
ffast2$Delay <- ifelse((ffast2$DDIM.Index<2)&(ffast2$ADIM.Index>0),0,1)
ffast2 <- ffast2[,c(1,2,3,6,9,8)]
ffast2 <- ffast2 %>% mutate_all(as.factor)
ffast2X <- as(ffast2,"transactions")
ruleset6 <- apriori(ffast2X,
                    parameter = list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs",rhs=("LTR.Index=1")))
inspectDT(ruleset6)
#promoters: model does not work
#detractors: origin=texas 



#########################For Northwest Business
nwb <- filter(newdata,newdata$Partner.Code=="OO")
#customer oriented
nw <- nwb[,c(3,10,14,25)]
#apply association rules to detractors
nw <- nw %>% mutate_all(as.factor)
str(nw)
nwX <- as(nw,"transactions")
ruleset7 <- apriori(nwX,
                    parameter = list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset7)
#promoters: gold+business+eco (but not very high lift)
#detractors: personal travel

#flights oriented columns
nw2 <- nwb[,c(17,18,19,20,21,23,24,25)]
#create a new column, if delayed, show 1, if no delay show 0
nw2$Delay <- ifelse((nw2$DDIM.Index<2)&(nw2$ADIM.Index>0),0,1)
nw2 <- nw2[,c(1,2,3,6,9,8)]
nw2 <- nw2 %>% mutate_all(as.factor)
nw2X <- as(nw2,"transactions")
ruleset8 <- apriori(nw2X,
                    parameter = list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset8)
#promoters: no conclusion
#detractors: origin=texas 




#########################For South East
se <- filter(newdata,newdata$Partner.Code=="US")
#customer oriented
se1 <- se[,c(3,10,14,25)]
#apply association rules to detractors
se1 <- se1 %>% mutate_all(as.factor)
str(se1)
se1X <- as(se1,"transactions")
ruleset9 <- apriori(se1X,
                    parameter = list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset9)
#promoters: no conclusion
#detractors: personal travel
#           personal+blue

#flights oriented columns
se2 <- se[,c(17,18,19,20,21,23,24,25)]
#create a new column, if delayed, show 1, if no delay show 0
se2$Delay <- ifelse((se2$DDIM.Index<2)&(se2$ADIM.Index>0),0,1)
se2 <- se2[,c(1,2,3,6,9,8)]
se2 <- se2 %>% mutate_all(as.factor)
se2X <- as(se2,"transactions")
ruleset10 <- apriori(se2X,
                    parameter = list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset10)
#promoters: origin=florida + very short flight (but only a few counts)
#detractors: no conclusion



#########################For Oursin Airlines
our <- filter(newdata,newdata$Partner.Code=="OU")
#customer oriented
os1 <- our[,c(3,10,14,25)]
#apply association rules to detractors
os1 <- os1 %>% mutate_all(as.factor)
str(os1)
os1X <- as(os1,"transactions")
ruleset11 <- apriori(os1X,
                    parameter = list(support=0.005,confidence=0.5),
                    appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset11)
#promoters: silver+business (very few counts)
#detractors: personal+blue


#flights oriented columns
os2 <- our[,c(17,18,19,20,21,23,24,25)]
#create a new column, if delayed, show 1, if no delay show 0
os2$Delay <- ifelse((os2$DDIM.Index<2)&(os2$ADIM.Index>0),0,1)
os2 <- os2[,c(1,2,3,6,9,8)]
os2 <- os2 %>% mutate_all(as.factor)
os2X <- as(os2,"transactions")
ruleset12 <- apriori(os2X,
                     parameter = list(support=0.005,confidence=0.5),
                     appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset12)
#promoters: no conclusion
#detractors: destination=penn  (very high lift, very few counts)
#           [2] from texas to virginia (very high lift, very few counts)





#########################For Paul Smith
ps <- filter(newdata,newdata$Partner.Code=="AA")
#customer oriented
ps1 <- ps[,c(3,10,14,25)]
#apply association rules to detractors
ps1 <- ps1 %>% mutate_all(as.factor)
str(ps1)
ps1X <- as(ps1,"transactions")
ruleset13 <- apriori(ps1X,
                     parameter = list(support=0.005,confidence=0.5),
                     appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset13)
#promoters: gold+business
#detractors: personal+blue+eco


#flights oriented columns
ps2 <- ps[,c(17,18,19,20,21,23,24,25)]
#create a new column, if delayed, show 1, if no delay show 0
ps2$Delay <- ifelse((ps2$DDIM.Index<2)&(ps2$ADIM.Index>0),0,1)
ps2 <- ps2[,c(1,2,3,6,9,8)]
ps2 <- ps2 %>% mutate_all(as.factor)
ps2X <- as(ps2,"transactions")
ruleset14 <- apriori(ps2X,
                     parameter = list(support=0.005,confidence=0.5),
                     appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset14)
#promoters: no conclusion
#detractors: no conclusion



#########################For Enjoy Flying
ef <- filter(newdata,newdata$Partner.Code=="MQ")
#customer oriented
ef1 <- ef[,c(3,10,14,25)]
#apply association rules to detractors
ef1 <- ef1 %>% mutate_all(as.factor)
str(ef1)
ef1X <- as(ef1,"transactions")
ruleset15 <- apriori(ef1X,
                     parameter = list(support=0.005,confidence=0.5),
                     appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset15)
#promoters: gold+business+eco  
#detractors: personal+blue


#flights oriented columns
ef2 <- ef[,c(17,18,19,20,21,23,24,25)]
#create a new column, if delayed, show 1, if no delay show 0
ef2$Delay <- ifelse((ef2$DDIM.Index<2)&(ef2$ADIM.Index>0),0,1)
ef2 <- ef2[,c(1,2,3,6,9,8)]
ef2 <- ef2 %>% mutate_all(as.factor)
ef2X <- as(ef2,"transactions")
ruleset16 <- apriori(ef2X,
                     parameter = list(support=0.005,confidence=0.5),
                     appearance = list(default="lhs",rhs=("LTR.Index=3")))
inspectDT(ruleset16)
#promoters: no conclusion
#detractors: origin=Texas (but very few counts)