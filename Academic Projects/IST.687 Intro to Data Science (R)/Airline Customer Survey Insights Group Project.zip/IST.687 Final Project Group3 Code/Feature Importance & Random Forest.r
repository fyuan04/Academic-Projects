
#Installing the supporting libraries for running our random forest model
#install.packages("randomForest")
#install.packages("mlbench")
#install.packages("caret")
#install.packages('e1071', dependencies=TRUE)


#Importing the required libraries
library(ggplot2)
library(randomForest)
library(mlbench)
library(caret)
library(tidyverse)

#Setting the working directory
#setwd("C:/Users/ACER/Desktop/ISTX87/Project/")

#Reading the data from the csv file
data1 <- read.csv("revision.csv", header = TRUE)

#Removing the longitude, latitude, FreeText, Class, Flight Cancelled 
data1<-data1[,c(-16,-1,-2,-27:-31)]

colnames_factor<-c('Age_Index','FPY_Index','Loyalty_Index','Weekday','TFFA_Index','Shopping_Index',
                   'Departure_Index','DDIM_Index','ADIM_Index','FTIM_Index','Distance._Index',
                   'LTR_Index','Price.Sensitivity','Year.of.First.Flight')

data1[colnames_factor]<-lapply(data1[colnames_factor],factor)


set.seed(100)
train <- sample(nrow(data1), 0.9*nrow(data1), replace = FALSE)
TrainSet <- data1[train,]
ValidSet <- data1[-train,]

str(TrainSet)

model1 <- randomForest(LTR_Index~ ., data = TrainSet, importance = TRUE,
                       replace=FALSE,ntree = 100,
                       mtry=sqrt(ncol(TrainSet)),nodesize = 10)

mean(predict(model1,TrainSet) == TrainSet$LTR_Index)

mean(predict(model1,ValidSet) == ValidSet$LTR_Index)

feat_imp_df <- importance(model1) %>% 
  data.frame() %>% 
  mutate(feature = row.names(.)) 

# plotting the feature importances
ggplot(feat_imp_df, aes(x = reorder(feature, MeanDecreaseGini), 
                        y = MeanDecreaseGini)) +
  geom_bar(stat='identity') +
  coord_flip() +
  theme_classic() +
  labs(
    x     = "Feature",
    y     = "Importance",
    title = "Feature Importance: <Model>"
  )


