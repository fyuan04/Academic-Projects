##### data cleaning and categorization
library(dplyr)
library(tidyverse)

#readin data
df <- jsonlite::fromJSON("fall2019-survey-M03.json")
#remove free text
df <- df[,-32]
#remove canceled flight rows
df <- filter(df,df$Flight.cancelled=="No")
#remove the whole wor containing the missing value of likelihood to recommend
df <- df[-as.numeric(rownames(df[is.na(newdata$Likelihood.to.recommend),] )),]
#replace the NAs in the arrival deplay column with 0
df$Arrival.Delay.in.Minutes[is.na(df$Arrival.Delay.in.Minutes)] <- 0
#taking 500miles/hour (8.333 miles/min) as the average speed of commercial palnes
#replace the NAs in the flight time column with our approximation method 
df$Flight.time.in.minutes[is.na(df$Flight.time.in.minutes)] <- round(df$Flight.Distance[is.na(df$Flight.time.in.minutes)]/8.333)
#all the NAs are taken care of 

#### data categorization
#for futhur analysis, we would like to categorize some numerical columns to factors
#all categorizations are left closed and right open
#for age
AgeIndex <- cut(df$Age,breaks = c(0,30,40,50,60,100),labels = c(1,2,3,4,5),right = FALSE)
#for flights per year
FPYIndex <- cut(df$Flights.Per.Year,breaks = c(0,10,20,30,40,100),labels = c(1,2,3,4,5),right = FALSE)
#for loyalty
LoyaltyIndex <- cut(df$Loyalty,breaks = c(-1.5,-0.5,0,0.5,1.5),labels = c(1,2,3,4),right = FALSE)
#for total frequent flight accounts
TFFAIndex <- cut(df$Total.Freq.Flyer.Accts,breaks = c(0,0.9,1.9,2.9,100),labels = c(1,2,3,4),right = FALSE)
#for shopping
ShoppingIndex <- cut(df$Shopping.Amount.at.Airport,breaks = c(0,0.9,20,50,100,700),labels = c(1,2,3,4,5),right = FALSE)
#for E&D
EDIndex <- cut(df$Eating.and.Drinking.at.Airport,breaks = c(0,20,40,60,100,900),labels = c(1,2,3,4,5),right = FALSE)
#for departure hour
DepartureIndex <- cut(df$Scheduled.Departure.Hour,breaks = c(0,6,12,17,24.1),labels = c(1,2,3,4),right = FALSE)
#for departure delay
DDIMIndex <- cut(df$Departure.Delay.in.Minutes,breaks =c(0,0.9,10,30,60,800),labels = c(1,2,3,4,5),right = FALSE)
#for arrival delay
ADIMIndex <- cut(df$Arrival.Delay.in.Minutes,breaks = c(0,0.9,10,30,60,800),labels = c(1,2,3,4,5),right = FALSE)
#for flight time 
FTIMIndex <- cut(df$Flight.time.in.minutes,breaks = c(0,60,90,120,180,500),labels = c(1,2,3,4,5),right = FALSE)
#for flight distance
DistanceIndex <- cut(df$Flight.Distance,breaks = c(0,300,500,800,1200,3000),labels = c(1,2,3,4,5),right = FALSE)
#for likelihood to recommend (1 for detractors, 2 for passive, and 3 for promoters)
LTRIndex <- cut(df$Likelihood.to.recommend,breaks = c(0,7,9,11),labels = c(1,2,3),right = FALSE)
#create a dataframe of categorized data
cat <- data.frame("Destination.City"=df$Destination.City,"Origin.City"=df$Origin.City,"Airline.Status"=df$Airline.Status,
                  "Age.Index"=AgeIndex,"Gender"=df$Gender,"Price.Sensitivity"=df$Price.Sensitivity,
                  "Year.of.First.Flight"=df$Year.of.First.Flight,"FPY.Index"=FPYIndex,"Loyalty.Index"=LoyaltyIndex,
                  "Type.of.Travel"=df$Type.of.Travel,"TFFA.Index"=TFFAIndex,"Shopping.Index"=ShoppingIndex,
                  "E&D.Index"=EDIndex,"Class"=df$Class,"Partner.Code"=df$Partner.Code,"Partner.Name"=df$Partner.Name,
                  "Origin.State"=df$Origin.State,"Destination.State"=df$Destination.State,"Departure.Index"=DepartureIndex,
                  "DDIM.Index"=DDIMIndex,"ADIM.Index"=ADIMIndex,"Flight.cancelled"=df$Flight.cancelled,"FTIM.Index"=FTIMIndex,
                  "Distance.Index"=DistanceIndex,"LTR.Index"=LTRIndex,"olong"=df$olong,"olat"=df$olat,"dlong"=df$dlong,"dlat"=df$dlat)
#export the dataframe to a .csv file
write.csv(cat,'revision.csv',row.names = FALSE)
