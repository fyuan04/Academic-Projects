#installing packages
library(jsonlite)
library(RCurl)
library(tibble)
library(magrittr)
library(dplyr)
library(stringr)
#install.packages("Hmisc")
library(Hmisc)
library(readr)
library(tidyverse)
library(lubridate)
library(anytime)
library(zipcode)
library(DataCombine)
#loading the dataset in
dataset <- getURL("https://s3.us-east-1.amazonaws.com/blackboard.learn.xythos.prod/5956621d575cd/8614410?response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27fall2019-survey-M03.json&response-content-type=application%2Fjson&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20191202T182305Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=AKIAIL7WQYDOOHAZJGWQ%2F20191202%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=b99bd652571cbb50805aa722eb61182bec8098f356ea7b773e24e49430af1528")
df <- jsonlite::fromJSON(dataset)
#write.csv(df, file="projectdata.csv")
df <-read_csv("projectdata.csv")
df <-data.frame(df)
str(df$Flight.date)
typeof(df$Flight.date)
df$Likelihood.to.recommend[is.na(df$Likelihood.to.recommend)] <- 0
library(maps)
library(ggplot2)
library(ggmap)
#making the latitude and longtiude usable for the ggmaps
df$olat <- as.double(df$olat)
df$olong <- as.double(df$olong)
#creating a table  that will be used in the maps to easily display the data. 
summaryDF2 <- df%>%
  group_by(Origin.City, Origin.State)%>%
  summarise(likelihood=mean(Likelihood.to.recommend),delay=sum(Departure.Delay.in.Minutes), olat=mean(olat),olong=mean(olong))
#you need to make this lowercase to make the states match to the US
summaryDF2$Origin.State <- tolower(summaryDF2$Origin.State)
summaryDF2
#making the graph of the states to see which stastes had the lowest and highest score to recommend.
summarydf3 <- summaryDF2 %>%
  group_by(Origin.State) %>%
  summarise(likelihood=mean(likelihood))
summarydf3
plot1 <- ggplot(summarydf3, aes(x=Origin.State,y=likelihood))
plot1 <- plot1 + geom_bar(stat = "identity")
#mkaing the plot at a 90 degree angle so that you can see the state names
plot1 <- plot1 + theme(axis.text =
                               element_text(angle=90,hjust=1))
plot1
#getting the data ready for the maps that shows the states that have the highest and lowest likelihood to succed and sized by the amount of delays.
us <- map_data("state")
ggplot <- ggplot(summaryDF2,aes(map_id=Origin.State))
ggplot <- ggplot +geom_map(map=us, aes(fill=summaryDF2$likelihood))
ggplot <-ggplot + geom_point(aes(x=summaryDF2$olong,y=summaryDF2$olat,color="darkgreen", size=summaryDF2$delay))
ggplot <- ggplot + expand_limits(x=us$long,y=us$lat)
ggplot
summaryDF2
#getting the day of week from the flight date to use in a regression or statistical analysis
df$date <- weekdays(df$Flight.date)
#reading another csv with the columns scaled differently
#making all of the flights have a one so that we can count the number of flights from each origin city.
df$flights <- 1
#summary is being groups by shopping and food amount by each origin city using tidyverse.
summary <- df%>%
  group_by(Origin.City)%>%
  summarise(shopping=mean(Shopping.Amount.at.Airport), food=mean(Eating.and.Drinking.at.Airport), likelihood=mean(Likelihood.to.recommend), flight=sum(flights))
summary
View(summary)

#getting the likelihood to recommend by the day of the week using tidyverse.
dates <- df %>%
  group_by(date) %>%
  summarise(lik=mean(Likelihood.to.recommend))
dates
#graphing the results of dates uding tidyverse
d <-ggplot(dates,aes(x = date, y = lik)) + 
  geom_col()+ coord_cartesian(ylim = c(6.90,7.23))
d


#linear model on the likelhiood to recommend based on delays and origin cities
lm2 <- lm(df$Likelihood.to.recommend ~ df$Origin.State+df$date+df$Departure.Delay.in.Minutes+df$Arrival.Delay.in.Minutes+df$date+df$Flight.cancelled+df$Scheduled.Departure.Hour)
summary(lm2)
#getting rid of more NAs
df$Arrival.Delay.in.Minutes[is.na(df$Arrival.Delay.in.Minutes)] <- 0
df$Departure.Delay.in.Minutes[is.na(df$Departure.Delay.in.Minutes)] <- 0
df$Likelihood.to.recommend[is.na(df$Likelihood.to.recommend)] <- 0
df$Likelihood.to.recommend[is.na(df$Likelihood.to.recommend)] <- 0

#creating another column to categorize flights cancelled by making a 1 yes and a 0 no.
df$cancel <- ifelse(df$Flight.cancelled=="Yes",1,0)
#Using tidyverse to get the departure delay in minutes by day of the week and the number of cancelled flights.
f <- df %>%
  group_by(date) %>%
  summarise(delay=mean(Departure.Delay.in.Minutes),cancel=sum(cancel))
f
#alinging the days of the weeks in chronological order
f$date <- factor(f$date, levels= c("Sunday", "Monday", 
                                         "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"))

f[order(f$date), ]

#plotting by date of week on the x-axis, delay time on the y, sized by the number of canceled flights
g <- ggplot(f, aes(x=date,y=delay))
g <-g+geom_point(aes(x=date,y=delay,color="blue", size=cancel))
g <- g+ xlab("Day of Week")+ylab("Average Delay Time")
g

#getting partner name and type of travel with likelihood to recommend
flight <- df %>%
  group_by(Partner.Name, Type.of.Travel) %>%
  summarise(Likelihood=mean(Likelihood.to.recommend))

#linear model showing the likelihood to recommend as the dependent variable and shopping, eating, and drinking as the dependent variable
flightlm2 <- lm(df$Likelihood.to.recommend~ df$Shopping.Amount.at.Airport+df$Eating.and.Drinking.at.Airport+df$Origin.City)
summary(lm2)

#plotting the amount of shopping at the airport in contrast to  likelihood to recommend.
l <- ggplot(df, aes(x=Shopping.Amount.at.Airport,y=Likelihood.to.recommend))
l<- l+geom_col()
l


#filter the origin state so that we can analyse why the LTR in Texas is so low coompared to other states
flights1 <- flight %>%
  filter(str_trim(Origin.State)=="Texas")
flights1
#using GGplot to get the partner names with origin flights within the state of texas. Clear that flyfast is lower than any of the other groups
stateplot <-ggplot(flights1,aes(x=Partner.Name,y=Likelihood,fill=flights))
stateplot <- stateplot +geom_bar(stat="identity")
stateplot <- stateplot + theme(axis.text =
                                  element_text(angle=90,hjust=1))
stateplot

#Filtering by getting rid of the partners and giving it just Southeast Airlines Co.
SE <-df %>%
  filter(str_trim(Partner.Name)=="Southeast Airlines Co.")
SE

#grouping by airline status and type of travel to see if the airlines status or type of travel has an effect on LTR.
SE1 <- SE %>%
  group_by(Airline.Status,Type.of.Travel) %>%
  summarise(likelihood=mean(Likelihood.to.recommend),flight=sum(flights))
SE1

Southeast <-ggplot(SE1,aes(x=Type.of.Travel,y=likelihood))
Southeast <- Southeast+ geom_point(aes(size=Airline.Status))
Southeast
#it is clear that blue and personal travelers have a lower likelihood to recommend than other groups.


dfff <- df %>%
  group_by(Partner.Name) %>%
  summarise(likelihood=mean(Likelihood.to.recommend))
dfff
#just shows that Flyfast Airlines has the lowest likelihood to recommend.

df$cancel <-df$cancel[is.na(df$cancel)] <- 0


#input the cleaned dataframe with categorized factors
df <- read.csv(file = "revision.csv")
#manideep
#average rating based on departure delays and Type of Travel
df %>% 
  group_by(departureDelay,Type.of.Travel) %>%
  summarise(avgRating=mean(Likelihood.to.recommend,na.rm = TRUE))%>%
  ggplot()+
  geom_bar(aes(x=departureDelay,y=avgRating,fill=Type.of.Travel),stat = "identity",position = "dodge")

#average rating based on departure delays and Gender
df %>% 
  group_by(departureDelay,Gender) %>%
  summarise(avgRating=mean(Likelihood.to.recommend,na.rm = TRUE))%>%
  ggplot()+
  geom_bar(aes(x=departureDelay,y=avgRating,fill=Gender),stat = "identity",position = "dodge")
#Spending habits according to Gender
df %>% 
  group_by(Gender) %>%
  summarise(shop=mean(Shopping.Amount.at.Airport,na.rm = T),
            Dining=mean(Eating.and.Drinking.at.Airport,na.rm = T)) %>%
  ggplot()+
  geom_bar(aes(x=Gender,y=shop,fill=Dining),stat="identity",position = 'dodge')+
  ylab("Average of Shopping Amount")

#Spending habits according to Type of travel
df %>% 
  group_by(Type.of.Travel) %>%
  summarise(shop=mean(Shopping.Amount.at.Airport,na.rm = T),
            Dining=mean(Eating.and.Drinking.at.Airport,na.rm = T)) %>%
  ggplot()+
  geom_bar(aes(x=Type.of.Travel,y=shop,fill=Dining),stat="identity",position = 'dodge')+
  ylab("Average of Shopping Amount")
